//
// Created by asafk on 01/05/2021.
//

#ifndef EX1_LINKEDLIST_H
#define EX1_LINKEDLIST_H

typedef struct LinkedList *List;

#endif //EX1_LINKEDLIST_H
