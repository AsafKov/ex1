#include "map.h"
#include <stdlib.h>

#define NULL_ARGUMENT_INDICATOR (-1)

typedef struct node_t{
    void *element;
    struct node_t *next;
} *Node;

struct Map_t {
    copyMapDataElements copyDataFunction;
    copyMapKeyElements copyMapKeyFunction;
    freeMapDataElements freeMapDataFunction;
    freeMapKeyElements freeMapKeyFunction;
    compareMapKeyElements compareMapKeyFunction;
    Node keyElementsHead;
    Node dataElementsHead;
    int iterator;
    int size;
};

/**
* mapCreate: Allocates a new empty map.
*
* @param copyDataElement - Function pointer to be used for copying data elements into
*  	the map or when copying the map.
* @param copyKeyElement - Function pointer to be used for copying key elements into
*  	the map or when copying the map.
* @param freeDataElement - Function pointer to be used for removing data elements from
* 		the map
* @param freeKeyElement - Function pointer to be used for removing key elements from
* 		the map
* @param compareKeyElements - Function pointer to be used for comparing key elements
* 		inside the map. Used to check if new elements already exist in the map.
* @return
* 	NULL - if one of the parameters is NULL or allocations failed.
* 	A new Map in case of success.
*/
Map mapCreate(copyMapDataElements copyDataElement,
              copyMapKeyElements copyKeyElement,
              freeMapDataElements freeDataElement,
              freeMapKeyElements freeKeyElement,
              compareMapKeyElements compareKeyElements){
    if(copyDataElement == NULL || compareKeyElements == NULL || freeDataElement == NULL
       || copyKeyElement == NULL || freeKeyElement == NULL) {
        return NULL;
    }
    Map map = malloc(sizeof(*map));
    if(map == NULL){
        return NULL;
    }
    map->copyDataFunction = copyDataElement;
    map->copyMapKeyFunction = copyKeyElement;
    map->freeMapDataFunction = freeDataElement;
    map->freeMapKeyFunction = freeKeyElement;
    map->compareMapKeyFunction = compareKeyElements;

    map->size = 0;
    map->keyElementsHead = malloc(sizeof(*(map->keyElementsHead)));
    if(map->keyElementsHead == NULL){
        free(map);
        return NULL;
    }
    map->dataElementsHead = malloc(sizeof(*(map->dataElementsHead)));
    if(map->keyElementsHead == NULL){
        free(map->dataElementsHead);
        free(map);
        return NULL;
    }
    return map;
}

/**
* mapDestroy: Deallocates an existing map. Clears all elements by using the
* stored free functions.
*
* @param map - Target map to be deallocated. If map is NULL nothing will be
* 		done
*/
void mapDestroy(Map map){
    if(map == NULL) return;
    map->freeMapDataFunction(map->dataElementsHead);
    map->freeMapKeyFunction(map->keyElementsHead);
}

/**
* mapCopy: Creates a copy of target map.
* Iterator values for both maps is undefined after this operation.
*
* @param map - Target map.
* @return
* 	NULL if a NULL was sent or a memory allocation failed.
* 	A Map containing the same elements as map otherwise.
*/
Map mapCopy(Map map){
    if(map == NULL){
        return NULL;
    }
    Map map_copy = mapCreate(map->copyDataFunction, map->copyMapKeyFunction,
                             map->freeMapDataFunction, map->freeMapKeyFunction,
                             map->compareMapKeyFunction);
    if(map_copy == NULL){
        return NULL;
    }

    map_copy->copyDataFunction(map->dataElementsHead);
    map_copy->copyMapKeyFunction(map->keyElementsHead);

    return map_copy;
}

/**
* mapGetSize: Returns the number of elements in a map
* @param map - The map which size is requested
* @return
* 	-1 if a NULL pointer was sent.
* 	Otherwise the number of elements in the map.
*/
int mapGetSize(Map map){
    if(map != NULL)
        return map->size;
    return NULL_ARGUMENT_INDICATOR;
}

/**
* mapContains: Checks if a key element exists in the map. The key element will be
* considered in the map if one of the key elements in the map it determined equal
* using the comparison function used to initialize the map.
*
* @param map - The map to search in
* @param element - The element to look for. Will be compared using the
* 		comparison function.
* @return
* 	false - if one or more of the inputs is null, or if the key element was not found.
* 	true - if the key element was found in the map.
*/
bool mapContains(Map map, MapKeyElement element){
    if(map == NULL || element == NULL){
        return false;
    }
    Node keysNode = map->keyElementsHead;
    for(int i=0; i<map->size; i++){
        if(map->compareMapKeyFunction((MapKeyElement)(keysNode->element), element) == 0){
            return true;
        }
        keysNode = keysNode->next;
    }
    return false;
}

/**
*	mapPut: Gives a specified key a specific value.
*  Iterator's value is undefined after this operation.
*
* @param map - The map for which to reassign the data element
* @param keyElement - The key element which need to be reassigned
* @param dataElement - The new data element to associate with the given key.
*      A copy of the element will be inserted as supplied by the copying function
*      which is given at initialization and old data memory would be
*      deleted using the free function given at initialization.
* @return
* 	MAP_NULL_ARGUMENT if a NULL was sent as map
* 	MAP_OUT_OF_MEMORY if an allocation failed (Meaning the function for copying
* 	an element failed)
* 	MAP_SUCCESS the paired elements had been inserted successfully
*/
MapResult mapPut(Map map, MapKeyElement keyElement, MapDataElement dataElement){
    if(map == NULL){
        return MAP_NULL_ARGUMENT;
    }
}

/**
*	mapGetFirst: Sets the internal iterator (also called current key element) to
*	the first key element in the map. There doesn't need to be an internal order
*  of the keys so the "first" key element is any key element.
*	Use this to start iterating over the map.
*	To continue iteration use mapGetNext
*
* @param map - The map for which to set the iterator and return the first
* 		key element.
* @return
* 	NULL if a NULL pointer was sent or the map is empty.
* 	The first key element of the map otherwise
*/
MapKeyElement mapGetFirst(Map map){
    if(map == NULL || map->size == 0)
        return NULL;
    return (MapKeyElement)(map->keyElementsHead->element);
}
